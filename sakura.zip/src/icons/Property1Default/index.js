export { Property1Default } from "./Property1Default";
