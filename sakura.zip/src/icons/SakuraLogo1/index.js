export { SakuraLogo1 } from "./SakuraLogo1";
